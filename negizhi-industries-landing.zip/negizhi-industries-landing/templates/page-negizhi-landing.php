<?php
/**
 * Template Name: Negizhi Industries Landing Page
 * Description: Standalone High-Performance Geometric Industrial Landing Page for Negizhi Industries.
 * Fully compatible with Hello Elementor, Elementor Canvas, and modern WordPress page builders.
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> prefix="og: https://ogp.me/ns#">
<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Geographic Meta Tags for Local SEO in Coimbatore, Tamil Nadu, India -->
    <meta name="geo.region" content="IN-TN" />
    <meta name="geo.placename" content="Coimbatore, Tamil Nadu, India" />
    <meta name="geo.position" content="11.0168;77.1265" />
    <meta name="ICBM" content="11.0168, 77.1265" />

    <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "ManufacturingBusiness",
        "@id": "https://negizhiindustries.com/#organization",
        "name": "Negizhi Industries",
        "legalName": "Negizhi Industries",
        "founder": {
          "@type": "Person",
          "name": "Mathibharathi Dhanaraj",
          "jobTitle": "Proprietor"
        },
        "url": "https://negizhiindustries.com",
        "logo": "https://negizhiindustries.com/assets/logo.png",
        "description": "Specialist for engineering plastic components for mechanical and electrical applications. Automatic injection moulding up to 200 Ton capacity, in-house tool room, CAD/CAM design and testing laboratory.",
        "foundingDate": "2025",
        "taxID": "33HFHPD0907Q1ZA",
        "telephone": "+91-86108-88097",
        "email": "plasticnegizhiindustries@gmail.com",
        "address": {
          "@type": "PostalAddress",
          "streetAddress": "5/160A, 79/2, Arasur Post, Arasur (PO), Sulur (TK)",
          "addressLocality": "Coimbatore",
          "addressRegion": "Tamil Nadu",
          "postalCode": "641407",
          "addressCountry": "IN"
        },
        "geo": {
          "@type": "GeoCoordinates",
          "latitude": "11.0168",
          "longitude": "77.1265"
        },
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "Engineering Plastic Components Catalog",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Product",
                "name": "Precision Delrin Gears",
                "description": "High mechanical strength, low friction Delrin 100P gears for industrial transmission."
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Product",
                "name": "Glass-Filled Nylon Switchgear Housings",
                "description": "Nylon 6 GF30% high-dielectric flame-retardant electrical switchgear housings."
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Product",
                "name": "Self-Lubricating Bushings and Sleeve Bearings",
                "description": "Wear-resistant flanged sleeves for rotating shaft assemblies."
              }
            }
          ]
        }
      }
    ]
  }
  </script>

    <?php wp_head(); ?>
</head>
<body <?php body_class('geometric-industrial-theme negizhi-standalone-page'); ?>>
<?php wp_body_open(); ?>

<div class="negizhi-wp-wrapper">


  <!-- Ambient Blueprint Grid and Neon Lights -->
  <div class="geo-grid-pattern"></div>
  <div class="geo-ambient-cyan"></div>
  <div class="geo-ambient-blue"></div>
  <div class="geo-vignette"></div>

  <!-- Top Geometric Micro-Coordinate Ticker Bar -->
  <div class="geo-ticker-bar">
    <div class="container geo-ticker-inner">
      <div class="geo-coord-badge">
        <span class="crosshair-icon">+</span>
        <span>LAT 11.0168° N, LON 77.1265° E // COIMBATORE, INDIA</span>
      </div>
      <div class="geo-ticker-status">
        <span class="status-indicator-dot"></span>
        <span>MANUFACTURING FLEET: 200-TON AUTOMATIC INJECTION UNIT ACTIVE</span>
      </div>
      <div class="geo-ticker-contact">
        <span>GSTIN: 33HFHPD0907Q1ZA</span>
        <span class="divider">|</span>
        <a href="tel:+918610888097" class="geo-tel-link">DIRECT: +91 86108 88097</a>
      </div>
    </div>
  </div>

  <!-- Main Navigation Header -->
  <header class="geo-header" id="headerNav">
    <div class="container geo-nav-container">
      <a href="#hero" class="geo-brand" aria-label="Negizhi Industries Home"><img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/logo-horizontal-clean.png'); ?>" alt="Negizhi Industries - Precision Engineering Plastic Components" class="geo-brand-logo" /></a>

      <!-- Primary Navigation Links -->
      <nav class="geo-nav-menu" aria-label="Primary Navigation">
        <ul class="geo-nav-list">
          <li><a href="#hero" class="geo-nav-link active">Home</a></li>
          <li><a href="#about" class="geo-nav-link">About</a></li>
          <li><a href="#moulding-cycle" class="geo-nav-link">Process</a></li>
          <li><a href="#products" class="geo-nav-link">Products</a></li>
          <li><a href="#machinery" class="geo-nav-link">Machinery</a></li>
          <li><a href="#materials" class="geo-nav-link">Materials</a></li>
          <li><a href="#tooling" class="geo-nav-link">Tooling</a></li>
          <li><a href="#quality" class="geo-nav-link">Quality</a></li>
          <li><a href="#clients" class="geo-nav-link">Clients</a></li>
          <li><a href="#contact" class="geo-nav-link">Contact</a></li>
        </ul>
      </nav>

      <!-- Action Buttons -->
      <div class="geo-header-actions">
        <a href="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'NEGIZHII.pdf'); ?>" download="Negizhi_Industries_Brochure.pdf" class="btn-geo-ghost" title="Download Official Company Brochure (PDF)">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          <span>PDF Profile</span>
        </a>
        <a href="#rfq" class="btn-geo-primary">
          <span>Request Quote</span>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
        </a>
        <!-- Mobile Navigation Menu Toggle -->
        <button class="geo-mobile-toggle" id="mobileMenuToggle" aria-label="Toggle navigation menu" aria-expanded="false" type="button">
          <span class="hamburger-bar"></span>
          <span class="hamburger-bar"></span>
          <span class="hamburger-bar"></span>
        </button>
      </div>
    </div>
  </header>

  <!-- Mobile Navigation Drawer Overlay -->
  <div class="geo-mobile-drawer" id="mobileNavDrawer" aria-hidden="true">
    <div class="drawer-backdrop" id="drawerBackdrop"></div>
    <div class="drawer-content">
      <div class="drawer-header">
        <a href="#hero" class="drawer-brand" aria-label="Negizhi Industries">
          <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/logo-horizontal-clean.png'); ?>" alt="Negizhi Industries Logo" class="drawer-logo" />
        </a>
        <button class="drawer-close-btn" id="drawerCloseBtn" aria-label="Close navigation menu" type="button">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>

      <div class="drawer-meta-badge">
        <span class="status-indicator-dot"></span>
        <span>COIMBATORE // 200T AUTOMATIC UNIT ACTIVE</span>
      </div>

      <nav class="drawer-nav" aria-label="Mobile Navigation">
        <ul class="drawer-nav-list">
          <li><a href="#hero" class="drawer-nav-link active"><span class="drawer-nav-idx">01</span><span>Home</span></a></li>
          <li><a href="#about" class="drawer-nav-link"><span class="drawer-nav-idx">02</span><span>About Negizhi</span></a></li>
          <li><a href="#moulding-cycle" class="drawer-nav-link"><span class="drawer-nav-idx">03</span><span>Moulding Cycle</span></a></li>
          <li><a href="#products" class="drawer-nav-link"><span class="drawer-nav-idx">04</span><span>Component Products</span></a></li>
          <li><a href="#machinery" class="drawer-nav-link"><span class="drawer-nav-idx">05</span><span>Machinery Fleet</span></a></li>
          <li><a href="#materials" class="drawer-nav-link"><span class="drawer-nav-idx">06</span><span>Polymer Materials</span></a></li>
          <li><a href="#tooling" class="drawer-nav-link"><span class="drawer-nav-idx">07</span><span>Tool &amp; Die Room</span></a></li>
          <li><a href="#quality" class="drawer-nav-link"><span class="drawer-nav-idx">08</span><span>Quality Lab</span></a></li>
          <li><a href="#clients" class="drawer-nav-link"><span class="drawer-nav-idx">09</span><span>Clients</span></a></li>
          <li><a href="#contact" class="drawer-nav-link"><span class="drawer-nav-idx">10</span><span>Contact &amp; RFQ</span></a></li>
        </ul>
      </nav>

      <div class="drawer-actions">
        <a href="#rfq" class="btn-geo-primary btn-full drawer-cta-btn">
          <span>Request Technical Quote</span>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
        </a>
        <a href="tel:+918610888097" class="drawer-tel-link">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
          <span>Direct Call: +91 86108 88097</span>
        </a>
        <a href="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'NEGIZHII.pdf'); ?>" download="Negizhi_Industries_Brochure.pdf" class="btn-geo-ghost btn-full">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          <span>Download PDF Profile</span>
        </a>
      </div>
    </div>
  </div>

  <!-- Instant Self-Executing Mobile Menu Controller -->
  <script>
    (function() {
      var lastToggle = 0;
      function openMobileMenu(e) {
        if (e) {
          if (typeof e.preventDefault === 'function') e.preventDefault();
          if (typeof e.stopPropagation === 'function') e.stopPropagation();
        }
        var drawer = document.getElementById('mobileNavDrawer');
        var toggle = document.getElementById('mobileMenuToggle');
        if (!drawer) return;
        drawer.classList.add('is-open');
        drawer.setAttribute('aria-hidden', 'false');
        if (toggle) {
          toggle.classList.add('is-active');
          toggle.setAttribute('aria-expanded', 'true');
        }
        document.body.classList.add('menu-locked');
      }

      function closeMobileMenu(e) {
        if (e) {
          if (typeof e.preventDefault === 'function') e.preventDefault();
          if (typeof e.stopPropagation === 'function') e.stopPropagation();
        }
        var drawer = document.getElementById('mobileNavDrawer');
        var toggle = document.getElementById('mobileMenuToggle');
        if (!drawer) return;
        drawer.classList.remove('is-open');
        drawer.setAttribute('aria-hidden', 'true');
        if (toggle) {
          toggle.classList.remove('is-active');
          toggle.setAttribute('aria-expanded', 'false');
        }
        document.body.classList.remove('menu-locked');
      }

      function toggleMobileMenu(e) {
        if (e) {
          if (e._toggleDone) return;
          e._toggleDone = true;
          if (typeof e.preventDefault === 'function') e.preventDefault();
          if (typeof e.stopPropagation === 'function') e.stopPropagation();
          if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
        }
        var now = Date.now();
        if (now - lastToggle < 300) return;
        lastToggle = now;

        var drawer = document.getElementById('mobileNavDrawer');
        if (!drawer) return;
        if (drawer.classList.contains('is-open')) {
          closeMobileMenu(e);
        } else {
          openMobileMenu(e);
        }
      }

      window.openMobileMenu = openMobileMenu;
      window.closeMobileMenu = closeMobileMenu;
      window.toggleMobileMenu = toggleMobileMenu;

      var toggleBtn = document.getElementById('mobileMenuToggle');
      if (toggleBtn) {
        toggleBtn.onclick = toggleMobileMenu;
      }
      var closeBtn = document.getElementById('drawerCloseBtn');
      if (closeBtn) {
        closeBtn.onclick = closeMobileMenu;
      }
      var backdrop = document.getElementById('drawerBackdrop');
      if (backdrop) {
        backdrop.onclick = closeMobileMenu;
      }
      var drawerLinks = document.querySelectorAll('.drawer-nav-link, .drawer-actions a');
      drawerLinks.forEach(function(l) {
        l.addEventListener('click', closeMobileMenu);
      });
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeMobileMenu();
      });
      window.addEventListener('resize', function() {
        if (window.innerWidth > 1140) closeMobileMenu();
      });
    })();
  </script>

  <main>
    <!-- ===================================================================
         GEOMETRIC STYLE MICRO HERO HEADER UI TEMPLATE
         =================================================================== -->
    <section class="geo-hero-section" id="hero">
      <div class="container geo-hero-grid">
        
        <!-- Hero Left: Strategic Headlines & Micro Spec Badges -->
        <div class="geo-hero-left">
          
          <div class="geo-micro-badge">
            <span class="geo-tag-bracket">[</span>
            <span class="geo-tag-dot"></span>
            <span class="geo-tag-text">PRECISION PLASTIC ENGINEERING // ESTD 2025</span>
            <span class="geo-tag-bracket">]</span>
          </div>

          <h1 class="geo-hero-title">
            <span class="title-sub">CRAFTING QUALITY</span>
            <span class="title-main gradient-cyan-blue">SHAPING TOMORROW</span>
          </h1>

          <p class="geo-hero-lead">
            <strong>Negizhi Industries</strong> is Coimbatore's premier specialist for high-precision <strong>Engineering Plastic Components</strong> for mechanical and electrical applications. Equipped with horizontal automatic injection moulding machines up to <strong>200-Ton capacity</strong>, in-house tool room capabilities, and rigorous value engineering.
          </p>

          <div class="geo-hero-cta-group">
            <a href="#products" class="btn-geo-primary btn-large">
              <span>View Product Components</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </a>
            <a href="#moulding-cycle" class="btn-geo-secondary btn-large">
              <span>Interactive Cycle Simulation</span>
            </a>
          </div>

          <!-- Micro Technical Specs Row -->
          <div class="geo-micro-specs-row">
            <div class="micro-spec-box">
              <span class="spec-label">CLAMPING CAPACITY</span>
              <span class="spec-value">200 TONS</span>
              <span class="spec-sub">Haitian Automatic</span>
            </div>
            <div class="micro-spec-divider"></div>
            <div class="micro-spec-box">
              <span class="spec-label">TOLERANCE PRECISION</span>
              <span class="spec-value">±0.01 MM</span>
              <span class="spec-sub">Mitutoyo Calibration</span>
            </div>
            <div class="micro-spec-divider"></div>
            <div class="micro-spec-box">
              <span class="spec-label">POLYMER PORTFOLIO</span>
              <span class="spec-value">14+ GRADES</span>
              <span class="spec-sub">Delrin, PA66 GF50, Noryl, TPE, PPS</span>
            </div>
          </div>

        </div>

        <!-- Hero Right: Geometric Frame with Highshine 200T Machine & Interactive Hotspots -->
        <div class="geo-hero-right">
          <div class="geo-display-card">
            
            <span class="corner-crosshair top-left">+</span>
            <span class="corner-crosshair top-right">+</span>
            <span class="corner-crosshair bottom-left">+</span>
            <span class="corner-crosshair bottom-right">+</span>

            <div class="geo-card-header">
              <div class="card-status-pill">
                <span class="pulse-cyan"></span>
                <span>HAITIAN 200T AUTOMATIC INJECTION UNIT</span>
              </div>
              <span class="card-metric-code">HS-150 // SPEC 2025</span>
            </div>

            <div class="geo-machine-viewport">
              <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/extracted/highshine_machine_clean.jpg'); ?>" alt="Highshine HS-150 200 Ton Automatic Injection Moulding Machine at Negizhi Industries" class="geo-machine-img" />
              <div class="geo-hud-scanline"></div>

              <!-- Interactive Hotspots -->
              <div class="geo-hotspot" style="top: 38%; left: 35%;" tabindex="0" aria-label="Hydraulic Clamping Unit specs">
                <div class="hotspot-pulse"></div>
                <div class="hotspot-tooltip">
                  <strong>200-Ton Hydraulic Toggle Clamp</strong>
                  <span>Die Bar: 510 × 510 mm • High-rigidity lock</span>
                </div>
              </div>

              <div class="geo-hotspot" style="top: 25%; left: 78%;" tabindex="0" aria-label="Injection Screw and Hopper specs">
                <div class="hotspot-pulse"></div>
                <div class="hotspot-tooltip">
                  <strong>Injection Screw &amp; 300°C Pre-Heater</strong>
                  <span>50mm Screw Dia • 480g Shot Weight</span>
                </div>
              </div>

              <div class="geo-hotspot" style="top: 55%; left: 66%;" tabindex="0" aria-label="Digital Micro-Controller specs">
                <div class="hotspot-pulse"></div>
                <div class="hotspot-tooltip">
                  <strong>Digital PLC Controller</strong>
                  <span>PID multi-zone heating • Sub-millisecond cycle timing</span>
                </div>
              </div>
            </div>

            <div class="geo-floating-widgets">
              <div class="geo-widget-badge">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                <div>
                  <div class="widget-title">Zero-Defect Quality</div>
                  <div class="widget-sub">Value Engineering Certified</div>
                </div>
              </div>

              <div class="geo-widget-badge">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                <div>
                  <div class="widget-title">In-House Tool Room</div>
                  <div class="widget-sub">CAD/CAM &amp; Die Manufacturing</div>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>

    <!-- ===================================================================
         CLIENT TRUSTED MARQUEE (Shanthi Gears, Sieger, Rydon, Safvolt, etc.)
         =================================================================== -->
    <section class="geo-clients-strip" id="clients">
      <div class="container">
        <div class="strip-header">
          <span class="geo-bracket-label">[ VALUED INDUSTRIAL PARTNERS &amp; GEAR MANUFACTURERS ]</span>
        </div>
        <div class="clients-marquee-grid">
          <div class="client-badge-card highlight">
            <span class="client-num">01</span>
            <span class="client-name">Shanthi Gears Limited (Murugappa Group)</span>
          </div>
          <div class="client-badge-card">
            <span class="client-num">02</span>
            <span class="client-name">Sieger Spintech Equipments Pvt Ltd</span>
          </div>
          <div class="client-badge-card">
            <span class="client-num">03</span>
            <span class="client-name">Rydon Industries Private Limited</span>
          </div>
          <div class="client-badge-card">
            <span class="client-num">04</span>
            <span class="client-name">Vignesh Gears Private Limited</span>
          </div>
          <div class="client-badge-card">
            <span class="client-num">05</span>
            <span class="client-name">Covai Gears Industries</span>
          </div>
          <div class="client-badge-card">
            <span class="client-num">06</span>
            <span class="client-name">Gishnu Gears - MM Gears Pvt Ltd Group</span>
          </div>
          <div class="client-badge-card highlight">
            <span class="client-num">07</span>
            <span class="client-name">Safvolt Switch Gears Private Limited</span>
          </div>
          <div class="client-badge-card">
            <span class="client-num">08</span>
            <span class="client-name">Bas-j Industries</span>
          </div>
          <div class="client-badge-card">
            <span class="client-num">09</span>
            <span class="client-name">Green Gears</span>
          </div>
          <div class="client-badge-card">
            <span class="client-num">10</span>
            <span class="client-name">Star Drives</span>
          </div>
        </div>
      </div>
    </section>

    <!-- ===================================================================
         SCROLL SEQUENCE ANIMATION: THE 200-TON PRECISION MOULDING CYCLE
         =================================================================== -->
    <section class="geo-section scroll-sequence-section" id="moulding-cycle">
      <div class="container">
        
        <div class="geo-section-header">
          <div class="geo-kicker">[ SCROLL SEQUENCE SIMULATION // PROCESS KINETICS ]</div>
          <h2 class="geo-section-title">The 200-Ton Precision Injection Moulding Cycle</h2>
          <p class="geo-section-subtitle">
            Scroll through to observe the synchronized mechanical stages of our high-pressure moulding cycle, from raw granule plasticization to micro-metrology quality release.
          </p>
        </div>

        <div class="scroll-sequence-wrapper" id="sequenceWrapper">
          
          <!-- Sticky Visualizer Viewport -->
          <div class="sequence-sticky-container">
            
            <div class="sequence-canvas-card">
              <!-- Real-time HUD Telemetry Headers -->
              <div class="sequence-hud-top">
                <div class="hud-item">
                  <span class="hud-label">ACTIVE STAGE</span>
                  <span class="hud-value" id="hudStageName">STAGE 01: GRANULE INGESTION</span>
                </div>
                <div class="hud-item">
                  <span class="hud-label">CLAMPING FORCE</span>
                  <span class="hud-value highlight-cyan" id="hudClamp">0 TONS</span>
                </div>
                <div class="hud-item">
                  <span class="hud-label">INJECTION PRESSURE</span>
                  <span class="hud-value" id="hudPressure">0 MPa</span>
                </div>
                <div class="hud-item">
                  <span class="hud-label">BARREL TEMP</span>
                  <span class="hud-value highlight-amber" id="hudTemp">300°C</span>
                </div>
                <div class="hud-item">
                  <span class="hud-label">CYCLE TIME</span>
                  <span class="hud-value" id="hudCycle">0.0s / 14.8s</span>
                </div>
              </div>

              <!-- Animated 60 FPS HTML5 Canvas Simulation -->
              <div class="canvas-render-container">
                <canvas id="mouldingCanvas" width="900" height="420" aria-label="Animated injection moulding cycle simulation"></canvas>
                <div class="canvas-scan-glow"></div>
              </div>

              <!-- Progress Bar Track -->
              <div class="sequence-progress-track">
                <div class="sequence-progress-bar" id="sequenceProgressBar"></div>
              </div>
            </div>

            <!-- Stage Navigation Pills (Click or Scroll) -->
            <div class="sequence-pills-row" id="sequencePillsRow">
              <button class="seq-pill active" data-step="1" type="button">01. Polymer Plastification</button>
              <button class="seq-pill" data-step="2" type="button">02. 200T Hydraulic Clamp</button>
              <button class="seq-pill" data-step="3" type="button">03. High-Pressure Injection</button>
              <button class="seq-pill" data-step="4" type="button">04. Conformal Cooling</button>
              <button class="seq-pill" data-step="5" type="button">05. Metrology &amp; Ejection</button>
            </div>

          </div>

          <!-- Scroll Triggers / Context Details (Hidden spatial triggers to drive sequence progress) -->
          <div class="sequence-scroll-track" id="sequenceScrollTrack">
            <div class="scroll-step" data-step="1">
              <div class="step-card">
                <span class="step-badge">STEP 01 OF 05</span>
                <h3>Virgin Polymer Dehumidification &amp; Heating</h3>
                <p>Granules enter the Sunsun 300°C pre-heater hopper to remove all trace moisture, eliminating hydrolysis and safeguarding high tensile strength in Delrin and Nylon 6 GF30%.</p>
              </div>
            </div>

            <div class="scroll-step" data-step="2">
              <div class="step-card">
                <span class="step-badge">STEP 02 OF 05</span>
                <h3>200-Ton Hydraulic Toggle Clamp Lock</h3>
                <p>The 510 × 510 mm platen locks with 2,000 kN clamping force, providing absolute zero-deflection seal across all parting lines to eliminate component flash.</p>
              </div>
            </div>

            <div class="scroll-step" data-step="3">
              <div class="step-card">
                <span class="step-badge">STEP 03 OF 05</span>
                <h3>High-Velocity Cavity Injection</h3>
                <p>The 50mm screw injects molten resin at up to 185 MPa through balanced runner gates, packing complex gear involutes and thin rib sections without internal voids.</p>
              </div>
            </div>

            <div class="scroll-step" data-step="4">
              <div class="step-card">
                <span class="step-badge">STEP 04 OF 05</span>
                <h3>Conformal Thermal Crystallization</h3>
                <p>Dual-channel temperature regulation cools the polymer at calibrated rates, locking in amorphous toughness and semicrystalline rigidity with sub-micron shrinkage control.</p>
              </div>
            </div>

            <div class="scroll-step" data-step="5">
              <div class="step-card">
                <span class="step-badge">STEP 05 OF 05</span>
                <h3>Demoulding &amp; Mitutoyo QA Verification</h3>
                <p>Parts are ejected smoothly without pin-marks and transferred directly to our QA bench for Mitutoyo vernier dimensional audit and Shore hardness testing.</p>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>

    <!-- ===================================================================
         PRODUCT LIST SECTION (HIGH QUALITY COMPONENT SHOWCASE)
         =================================================================== -->
    <section class="geo-section dark-alt" id="products">
      <div class="container">
        
        <div class="geo-section-header">
          <div class="geo-kicker">[ COMPONENT CATALOG // PRECISION PORTFOLIO ]</div>
          <h2 class="geo-section-title">High-Precision Engineering Plastic Components</h2>
          <p class="geo-section-subtitle">
            Explore our manufacturing portfolio across mechanical transmissions, electrical switchgear, precision fluidics, and custom insert overmoulded parts.
          </p>
        </div>

        <!-- Master Production Line Showcase Banner -->
        <div class="master-showcase-banner">
          <div class="master-showcase-media">
            <picture>
              <source srcset="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/master-component-showcase.webp'); ?>" type="image/webp" />
              <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/master-component-showcase.jpg'); ?>" alt="Negizhi Industries Complete Engineering Plastic Components Master Portfolio" class="master-showcase-img" loading="lazy" />
            </picture>
            <div class="master-showcase-badge">
              <span class="status-indicator-dot"></span>
              <span>COIMBATORE FACILITY // LIVE COMPONENT ARRAY</span>
            </div>
          </div>
          <div class="master-showcase-content">
            <div class="geo-kicker">[ PRODUCTION LINE SHOWCASE ]</div>
            <h3 class="master-showcase-title">100% In-House Manufactured Precision Components</h3>
            <p class="master-showcase-desc">
              From high-torque Delrin helical gears with splined metallic hubs to 5-frame motor fan cowls, shielded bearing rollers, Shore 92A/98A elastomeric spider couplings, and dual-brass insert brackets—manufactured to ±0.01 mm tolerance for Coimbatore's premier machine builders and electrical OEMs.
            </p>
            <div class="master-showcase-stats">
              <div class="showcase-stat-item">
                <span class="stat-number">200T</span>
                <span class="stat-label">Clamping Force</span>
              </div>
              <div class="showcase-stat-item">
                <span class="stat-number">±0.01 mm</span>
                <span class="stat-label">Mitutoyo Calibration</span>
              </div>
              <div class="showcase-stat-item">
                <span class="stat-number">14+</span>
                <span class="stat-label">Polymer Grades</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Product Filter Pills & Instant Component Search -->
        <div class="products-toolbar-bar">
          <div class="product-category-pills" id="productFilterPills">
            <button class="prod-filter-btn active" data-cat="all" type="button">All Components (10)</button>
            <button class="prod-filter-btn" data-cat="mechanical" type="button">Mechanical &amp; Gears (4)</button>
            <button class="prod-filter-btn" data-cat="electrical" type="button">Electrical &amp; Switchgear (2)</button>
            <button class="prod-filter-btn" data-cat="bushings" type="button">Bushings &amp; Bearings (1)</button>
            <button class="prod-filter-btn" data-cat="specialty" type="button">High-Heat &amp; Specialty (3)</button>
          </div>

          <div class="product-search-box">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input type="text" id="productSearchInput" placeholder="Search by component, polymer, or application..." />
          </div>
        </div>

        <!-- Product Cards Grid (All with Enhanced Real Industrial Photos) -->
        <div class="products-cards-grid" id="productGridContainer">
          
          <!-- Product 1: Precision Nylon 66 GF 50% Gears -->
          <article class="product-card" data-cat="mechanical">
            <div class="product-media-wrap">
              <picture>
                <source srcset="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/gear-delrin-helical.webp'); ?>" type="image/webp" />
                <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/gear-delrin-helical.jpg'); ?>" alt="Precision Nylon 66 GF 50% Involute Spur and Helical Gear with Splined Hub" class="product-img" loading="lazy" />
              </picture>
              <span class="product-tag-badge">MECHANICAL TRANSMISSION</span>
            </div>
            <div class="product-body">
              <h3 class="product-title">Precision Spur &amp; Helical Gears (Nylon 66 GF 50%)</h3>
              <p class="product-desc">High-torque, high-rigidity replacement for metallic gears featuring integrated internal splined hubs. 50% glass-fiber reinforced for superior tensile strength, dimensional stability, and low dynamic wear in demanding industrial drives.</p>
              
              <div class="product-spec-matrix">
                <div class="prod-spec-row">
                  <span class="spec-k">Polymer Grade:</span>
                  <span class="spec-v">Nylon 66 GF 50% (High Modulus Structural)</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Moulding Unit:</span>
                  <span class="spec-v">Haitian 200T / 90T Automatic</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Tolerance:</span>
                  <span class="spec-v">±0.01 mm (Mitutoyo Calibrated)</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Application:</span>
                  <span class="spec-v">Shanthi Gears, Sieger Spintech</span>
                </div>
              </div>

              <a href="#rfq" class="btn-geo-primary btn-full" onclick="preselectMaterial('Nylon 66 GF 50%', 'Precision Spur & Helical Gears (Nylon 66 GF 50%)')">Request Gear Quote</a>
            </div>
          </article>

          <!-- Product 2: Mechanical Gear Box Cooling Fan Cowls & Impellers -->
          <article class="product-card" data-cat="mechanical">
            <div class="product-media-wrap">
              <picture>
                <source srcset="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/motor-cooling-fan-family.webp'); ?>" type="image/webp" />
                <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/motor-cooling-fan-family.jpg'); ?>" alt="Mechanical Gear Box Cooling Fan Cowls and High-Flow Impellers Set" class="product-img" loading="lazy" />
              </picture>
              <span class="product-tag-badge">THERMAL AERODYNAMICS</span>
            </div>
            <div class="product-body">
              <h3 class="product-title">Mechanical Gear Box Cooling Fan Cowls &amp; Radial Impellers</h3>
              <p class="product-desc">Complete graduated range of 5 frame sizes of slotted mechanical gear box cooling cowls paired with multi-blade aerodynamic radial impellers for uniform industrial gear box airflow.</p>
              
              <div class="product-spec-matrix">
                <div class="prod-spec-row">
                  <span class="spec-k">Polymer Grade:</span>
                  <span class="spec-v">Nylon 6 GF30% / Impact Copolymer</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Range Sizes:</span>
                  <span class="spec-v">5 Standard Frame Series (63 to 132)</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Airflow Dynamic:</span>
                  <span class="spec-v">High-CFM Slotted Low-Vibration</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Application:</span>
                  <span class="spec-v">Mechanical Gear Boxes, Industrial Transmissions</span>
                </div>
              </div>

              <a href="#rfq" class="btn-geo-primary btn-full" onclick="preselectMaterial('Nylon 6 GF30%', 'Mechanical Gear Box Cooling Fan Cowl & Impeller')">Request Fan Quote</a>
            </div>
          </article>

          <!-- Product 3: PU Flexible Spider Couplings -->
          <article class="product-card" data-cat="mechanical">
            <div class="product-media-wrap">
              <picture>
                <source srcset="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/pu-spider-couplings-family.webp'); ?>" type="image/webp" />
                <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/pu-spider-couplings-family.jpg'); ?>" alt="Polyurethane Elastomer Flexible Spider Couplings" class="product-img" loading="lazy" />
              </picture>
              <span class="product-tag-badge">SHOCK &amp; VIBRATION DAMPING</span>
            </div>
            <div class="product-body">
              <h3 class="product-title">Polyurethane (PU) Flexible Spider Couplings</h3>
              <p class="product-desc">Four graduated frame sizes of Rotex-type elastomer spider inserts. Effectively absorbs angular shaft misalignments, damping high-frequency shocks and motor torsional flutter.</p>
              
              <div class="product-spec-matrix">
                <div class="prod-spec-row">
                  <span class="spec-k">Polymer Grade:</span>
                  <span class="spec-v">Thermoplastic Polyurethane (TPU)</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Durometer:</span>
                  <span class="spec-v">Shore 92A / 98A Calibrated</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Thermal Service:</span>
                  <span class="spec-v">-40°C to +90°C Continuous</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Application:</span>
                  <span class="spec-v">Motor-Gearbox Couplings, Star Drives</span>
                </div>
              </div>

              <a href="#rfq" class="btn-geo-primary btn-full" onclick="preselectMaterial('Polyurethane (PU)', 'PU Flexible Spider Coupling')">Request Coupling Quote</a>
            </div>
          </article>

          <!-- Product 4: Threaded Brass Insert Overmoulded Structural Bracket -->
          <article class="product-card" data-cat="mechanical">
            <div class="product-media-wrap">
              <picture>
                <source srcset="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/brass-insert-bracket.webp'); ?>" type="image/webp" />
                <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/brass-insert-bracket.jpg'); ?>" alt="Threaded Brass Insert Overmoulded Structural Bracket" class="product-img" loading="lazy" />
              </picture>
              <span class="product-tag-badge">INSERT OVERMOULDING</span>
            </div>
            <div class="product-body">
              <h3 class="product-title">Threaded Brass Insert Overmoulded Brackets</h3>
              <p class="product-desc">Precision vertical insert moulding integrating dual diamond-knurled brass threaded bushings directly into high-tensile structural polymers with extreme pullout strength.</p>
              
              <div class="product-spec-matrix">
                <div class="prod-spec-row">
                  <span class="spec-k">Technology:</span>
                  <span class="spec-v">15T Vertical Screw Injection Unit</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Pullout Force:</span>
                  <span class="spec-v">&gt; 8.5 kN Torque &amp; Axial Lock</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Thread Sizes:</span>
                  <span class="spec-v">Dual Knurled M4 / M5 / M6 / M8</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Application:</span>
                  <span class="spec-v">Gishnu Gears, Bas-j Industries</span>
                </div>
              </div>

              <a href="#rfq" class="btn-geo-primary btn-full" onclick="preselectMaterial('Nylon 6', 'Threaded Brass Overmould Bracket')">Request Insert Quote</a>
            </div>
          </article>

          <!-- Product 5: Precision Overmoulded Bearing Rollers -->
          <article class="product-card" data-cat="bushings">
            <div class="product-media-wrap">
              <picture>
                <source srcset="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/bearing-rollers-overmoulded.webp'); ?>" type="image/webp" />
                <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/bearing-rollers-overmoulded.jpg'); ?>" alt="Precision Overmoulded Bearing Roller Wheels and Sleeve Bushings" class="product-img" loading="lazy" />
              </picture>
              <span class="product-tag-badge">HEAVY DYNAMIC LOAD</span>
            </div>
            <div class="product-body">
              <h3 class="product-title">Overmoulded Bearing Rollers &amp; Sleeve Bushings</h3>
              <p class="product-desc">Precision overmoulded roller wheels with integrated shielded steel ball bearings. Provides smooth rolling motion, ultra-low rolling friction, and zero galling under sustained loads.</p>
              
              <div class="product-spec-matrix">
                <div class="prod-spec-row">
                  <span class="spec-k">Polymer Grade:</span>
                  <span class="spec-v">Delrin POM / Cast Polyamide</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Bearing Core:</span>
                  <span class="spec-v">Shielded Steel Ball Bearing Race</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Bore Fit:</span>
                  <span class="spec-v">H7 / g6 Standard Press-Fit</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Application:</span>
                  <span class="spec-v">Vignesh Gears, Covai Gears</span>
                </div>
              </div>

              <a href="#rfq" class="btn-geo-primary btn-full" onclick="preselectMaterial('Delrin (POM)', 'Overmoulded Bearing Roller')">Request Roller Quote</a>
            </div>
          </article>

          <!-- Product 6: Switchgear Housing & Terminal Box -->
          <article class="product-card" data-cat="electrical">
            <div class="product-media-wrap">
              <picture>
                <source srcset="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/switchgear-terminal-enclosure.webp'); ?>" type="image/webp" />
                <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/switchgear-terminal-enclosure.jpg'); ?>" alt="Glass-Filled Nylon Switchgear Terminal Housing" class="product-img" loading="lazy" />
              </picture>
              <span class="product-tag-badge">ELECTRICAL INSULATION</span>
            </div>
            <div class="product-body">
              <h3 class="product-title">Nylon 6 GF30% Switchgear Enclosures</h3>
              <p class="product-desc">Heavy-duty 30% glass-reinforced electrical terminal housings with circular conduit knockouts, mounting lugs, high dielectric breakdown resistance, and flame retardancy.</p>
              
              <div class="product-spec-matrix">
                <div class="prod-spec-row">
                  <span class="spec-k">Polymer Grade:</span>
                  <span class="spec-v">Polyamide 6 GF30% Reinforced</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Moulding Unit:</span>
                  <span class="spec-v">200-Ton High-Clamping Platen</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Flame Rating:</span>
                  <span class="spec-v">UL94 V-0 Self-Extinguishing</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Application:</span>
                  <span class="spec-v">Safvolt Switch Gears, Rydon</span>
                </div>
              </div>

              <a href="#rfq" class="btn-geo-primary btn-full" onclick="preselectMaterial('Nylon 6 GF30%', 'Switchgear Terminal Enclosure')">Request Housing Quote</a>
            </div>
          </article>

          <!-- Product 7: Optical PC Meter Cover -->
          <article class="product-card" data-cat="electrical">
            <div class="product-media-wrap">
              <picture>
                <source srcset="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/optical-meter-cover.webp'); ?>" type="image/webp" />
                <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/optical-meter-cover.jpg'); ?>" alt="Optical Polycarbonate (PC) Meter Covers" class="product-img" loading="lazy" />
              </picture>
              <span class="product-tag-badge">OPTICAL &amp; IMPACT PROOF</span>
            </div>
            <div class="product-body">
              <h3 class="product-title">Optical Polycarbonate (PC) Meter Covers</h3>
              <p class="product-desc">High-clarity, vandal-proof inspection window covers engineered for outdoor electricity meters, dial gauges, and industrial digital readouts.</p>
              
              <div class="product-spec-matrix">
                <div class="prod-spec-row">
                  <span class="spec-k">Polymer Grade:</span>
                  <span class="spec-v">Optical Virgin Polycarbonate (PC)</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Light Transmit:</span>
                  <span class="spec-v">92% Optical Clarity</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Impact Rating:</span>
                  <span class="spec-v">IK10 Shock &amp; UV Stabilized</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Application:</span>
                  <span class="spec-v">Power Distribution &amp; Digital Meters</span>
                </div>
              </div>

              <a href="#rfq" class="btn-geo-primary btn-full" onclick="preselectMaterial('Polycarbonate (PC)', 'Optical Meter Cover')">Request Cover Quote</a>
            </div>
          </article>

          <!-- Product 8: Aerator Plug for Mechanical Gear Box -->
          <article class="product-card" data-cat="specialty">
            <div class="product-media-wrap">
              <picture>
                <source srcset="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/fluidic-connectors-plugs.webp'); ?>" type="image/webp" />
                <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/fluidic-connectors-plugs.jpg'); ?>" alt="Aerator Plug for Mechanical Gear Box and Sealing Breather Plugs" class="product-img" loading="lazy" />
              </picture>
              <span class="product-tag-badge">GEARBOX AERATION &amp; SEALING</span>
            </div>
            <div class="product-body">
              <h3 class="product-title">Aerator Plug for Mechanical Gear Box</h3>
              <p class="product-desc">Precision molded breather and aerator plugs featuring elastomeric O-ring seals. Engineered for pressure equalization, thermal ventilation, and zero oil leakage in mechanical gear box housings.</p>
              
              <div class="product-spec-matrix">
                <div class="prod-spec-row">
                  <span class="spec-k">Polymer Grade:</span>
                  <span class="spec-v">Engineering Polypropylene (PP) / POM</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Thread Standards:</span>
                  <span class="spec-v">BSP / NPT Precision Molded Threads</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Sealing System:</span>
                  <span class="spec-v">Nitrile O-Ring &amp; Barb Lock</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Application:</span>
                  <span class="spec-v">Mechanical Gear Boxes, Speed Reducers</span>
                </div>
              </div>

              <a href="#rfq" class="btn-geo-primary btn-full" onclick="preselectMaterial('PP', 'Aerator Plug for Mechanical Gear Box')">Request Aerator Quote</a>
            </div>
          </article>

          <!-- Product 9: Production Cover for Warm Shaft -->
          <article class="product-card" data-cat="specialty">
            <div class="product-media-wrap">
              <picture>
                <source srcset="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/threaded-pipe-caps.webp'); ?>" type="image/webp" />
                <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/threaded-pipe-caps.jpg'); ?>" alt="Production Cover for Warm Shaft and Gearbox Protective Flange Caps" class="product-img" loading="lazy" />
              </picture>
              <span class="product-tag-badge">SHAFT &amp; FLANGE SHIELD</span>
            </div>
            <div class="product-body">
              <h3 class="product-title">Production Cover for Warm Shaft</h3>
              <p class="product-desc">Heavy-duty precision protective covers and chemical flanges manufactured from high-density polymers. Guarantees 100% thread shield, impact protection, and moisture barrier for warm shaft gearbox assemblies.</p>
              
              <div class="product-spec-matrix">
                <div class="prod-spec-row">
                  <span class="spec-k">Polymer Grade:</span>
                  <span class="spec-v">High Density Polyethylene (HDPE) / PP</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Fitment Standards:</span>
                  <span class="spec-v">Precision Warm Shaft &amp; Flange Seal</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Water Uptake:</span>
                  <span class="spec-v">&lt; 0.01% (Completely Inert)</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Application:</span>
                  <span class="spec-v">Warm Shaft Drives, Gearbox Protection</span>
                </div>
              </div>

              <a href="#rfq" class="btn-geo-primary btn-full" onclick="preselectMaterial('HDPE / LDPE', 'Production Cover for Warm Shaft')">Request Cover Quote</a>
            </div>
          </article>

          <!-- Product 10: Color-Coded Alignment Bullet Pins -->
          <article class="product-card" data-cat="specialty">
            <div class="product-media-wrap">
              <picture>
                <source srcset="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/alignment-bullet-pins.webp'); ?>" type="image/webp" />
                <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/products/alignment-bullet-pins.jpg'); ?>" alt="Color Coded Precision Alignment Bullet Pins and Masking Plugs" class="product-img" loading="lazy" />
              </picture>
              <span class="product-tag-badge">PRECISION TOOLING LOCATORS</span>
            </div>
            <div class="product-body">
              <h3 class="product-title">Color-Coded Alignment Bullet Pins &amp; Plugs</h3>
              <p class="product-desc">Precision tapered dowel locator pins and high-temperature masking stoppers in 4 distinct color-coded diameters for foolproof assembly line positioning and painting mask protection.</p>
              
              <div class="product-spec-matrix">
                <div class="prod-spec-row">
                  <span class="spec-k">Polymer Grade:</span>
                  <span class="spec-v">Impact Nylon 6 / Polyurethane TPU</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Color Coding:</span>
                  <span class="spec-v">Red, Natural, Blue, Orange</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Base Flange:</span>
                  <span class="spec-v">Integrated Ergonomic Rim Lock</span>
                </div>
                <div class="prod-spec-row">
                  <span class="spec-k">Application:</span>
                  <span class="spec-v">Assembly Fixtures, Paint Masking</span>
                </div>
              </div>

              <a href="#rfq" class="btn-geo-primary btn-full" onclick="preselectMaterial('Nylon 6', 'Alignment Bullet Pins')">Request Pin Quote</a>
            </div>
          </article>        </div>

      </div>
    </section>

    <!-- ===================================================================
         ABOUT US & VALUE ENGINEERING
         =================================================================== -->
    <section class="geo-section" id="about">
      <div class="container">
        
        <div class="geo-section-header">
          <div class="geo-kicker">[ CORPORATE PROFILE // COIMBATORE FOUNDATION ]</div>
          <h2 class="geo-section-title">Engineered to Power Mechanical &amp; Electrical Assemblies</h2>
          <p class="geo-section-subtitle">
            Founded in 2025 in Coimbatore, Tamil Nadu, <strong>Negizhi Industries</strong> bridges precision polymer science with industrial manufacturing rigor to eliminate product failure under extreme operating environments.
          </p>
        </div>

        <div class="geo-about-grid">
          <div class="about-card primary-highlight">
            <div class="about-card-badge">THE NEGIZHI METHODOLOGY</div>
            <h3 class="about-card-title">Value Engineering Without Compromising on Quality</h3>
            <p class="about-card-text">
              Our engineering team works closely with customers from part design through mould flow simulation, tooling fabrication, and mass production. By replacing expensive, heavy metal components with specialized engineering polymers (Delrin, 30% Glass-Filled Polyamide, PPS), we reduce component weight by up to 70%, eliminate corrosion, and lower unit manufacturing costs.
            </p>
            <ul class="about-check-list">
              <li>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                <span><strong>Full-Fledged Tool Room:</strong> Die design, machining, precision grinding, wire cutting, and EDM sparking.</span>
              </li>
              <li>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                <span><strong>Electrical R&amp;D:</strong> Formulations tailored for high dielectric breakdown and arc-track resistance.</span>
              </li>
              <li>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                <span><strong>Mechanical Testing Lab:</strong> Mitutoyo calipers, Shore hardness testing, bore gauges, and gram-level shot consistency.</span>
              </li>
            </ul>
          </div>

          <div class="about-card visual-card">
            <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/extracted/virgin_polymer_pellets.jpg'); ?>" alt="100% Virgin engineering grade plastic pellets used at Negizhi Industries" class="about-img" loading="lazy" />
            <div class="about-overlay-stat">
              <span class="stat-number">100%</span>
              <span class="stat-caption">Virgin Engineering Grade Polymers (DuPont, BASF, Sabic standard) with zero uncertified regrind</span>
            </div>
          </div>
        </div>

      </div>
    </section>

    <!-- ===================================================================
         MANUFACTURING INFRASTRUCTURE & MACHINERY FLEET
         =================================================================== -->
    <section class="geo-section dark-alt" id="machinery">
      <div class="container">
        
        <div class="geo-section-header">
          <div class="geo-kicker">[ PRODUCTION FLEET // HEAVY CLAMPING ]</div>
          <h2 class="geo-section-title">Injection Moulding Plant Infrastructure</h2>
          <p class="geo-section-subtitle">
            Equipped with horizontal automatic machines up to 200 Tons and vertical screw-type insert moulding units.
          </p>
        </div>

        <div class="machinery-grid">
          
          <!-- Machine 1: 200 Ton Haitian -->
          <div class="machine-card flagship">
            <div class="machine-badge">HEAVY TONNAGE FLAGSHIP</div>
            <h3 class="machine-name">Horizontal Automatic Injection Moulding Machine</h3>
            <div class="machine-make">Make: Haitian (200 Ton)</div>
            
            <div class="specs-data-grid">
              <div class="spec-cell">
                <span class="cell-label">Clamping Force:</span>
                <span class="cell-val">200 Ton (2,000 kN)</span>
              </div>
              <div class="spec-cell">
                <span class="cell-label">Die Bar Clearance:</span>
                <span class="cell-val">510 × 510 mm</span>
              </div>
              <div class="spec-cell">
                <span class="cell-label">Screw Diameter:</span>
                <span class="cell-val">50 mm</span>
              </div>
              <div class="spec-cell">
                <span class="cell-label">Shot / Sheet Weight:</span>
                <span class="cell-val">480 Grams</span>
              </div>
            </div>
            <div class="machine-tagline">Engineered for large multi-cavity gear moulds, heavy switchgear enclosures, and thick-walled pump bodies.</div>
          </div>

          <!-- Machine 2: 90 Ton Shine Well Taiwan -->
          <div class="machine-card">
            <div class="machine-badge">PRECISION SPEED UNIT</div>
            <h3 class="machine-name">Horizontal Automatic Injection Moulding Machine</h3>
            <div class="machine-make">Make: Shine Well Taiwan (90 Ton)</div>
            
            <div class="specs-data-grid">
              <div class="spec-cell">
                <span class="cell-label">Clamping Force:</span>
                <span class="cell-val">90 Ton</span>
              </div>
              <div class="spec-cell">
                <span class="cell-label">Die Bar Clearance:</span>
                <span class="cell-val">330 × 330 mm</span>
              </div>
              <div class="spec-cell">
                <span class="cell-label">Screw Diameter:</span>
                <span class="cell-val">32 mm</span>
              </div>
              <div class="spec-cell">
                <span class="cell-label">Shot Weight:</span>
                <span class="cell-val">150 Grams</span>
              </div>
            </div>
            <div class="machine-tagline">High-speed precision unit dedicated to tight-tolerance bushings, electrical connectors, and precision actuators.</div>
          </div>

          <!-- Machine 3: 15 Ton Vertical TEX AIR CBE -->
          <div class="machine-card">
            <div class="machine-badge">INSERT OVERMOULDING</div>
            <h3 class="machine-name">Vertical Screw Type Injection Moulding Machine</h3>
            <div class="machine-make">Make: TEX AIR CBE (15 Ton)</div>
            
            <div class="specs-data-grid">
              <div class="spec-cell">
                <span class="cell-label">Clamping Force:</span>
                <span class="cell-val">15 Ton</span>
              </div>
              <div class="spec-cell">
                <span class="cell-label">Die Bar Clearance:</span>
                <span class="cell-val">200 × 250 mm</span>
              </div>
              <div class="spec-cell">
                <span class="cell-label">Orientation:</span>
                <span class="cell-val">Vertical Clamping / Screw</span>
              </div>
              <div class="spec-cell">
                <span class="cell-label">Specialization:</span>
                <span class="cell-val">Metal Insert Overmoulding</span>
              </div>
            </div>
            <div class="machine-tagline">Specialized for manual and semi-automated brass knurled insert placement, terminal collars, and micro gears.</div>
          </div>

          <!-- Machine 4: Semi-Automatic Hand Mould -->
          <div class="machine-card">
            <div class="machine-badge">RAPID PILOT PROTOTYPE</div>
            <h3 class="machine-name">Semi-Automatic Injection Moulding Machine</h3>
            <div class="machine-make">Make: TEX AIR CBE (Hand Mould)</div>
            
            <div class="specs-data-grid">
              <div class="spec-cell">
                <span class="cell-label">Shot Capacity:</span>
                <span class="cell-val">40 Grams</span>
              </div>
              <div class="spec-cell">
                <span class="cell-label">Operation:</span>
                <span class="cell-val">Semi-Automatic Hand Mould</span>
              </div>
              <div class="spec-cell">
                <span class="cell-label">Tooling Cost:</span>
                <span class="cell-val">Ultra-Low Initial Capex</span>
              </div>
              <div class="spec-cell">
                <span class="cell-label">Batch Size:</span>
                <span class="cell-val">Sample Trials &amp; Pilot Runs</span>
              </div>
            </div>
            <div class="machine-tagline">Fast turnaround for prototype feasibility batches, pre-production trial samples, and custom small-lot runs.</div>
          </div>

        </div>

        <!-- Auxiliary Equipment Strip -->
        <div class="aux-machinery-panel">
          <div class="aux-header">AUXILIARY SUPPORT &amp; MATERIAL PREPARATION PLANT:</div>
          <div class="aux-items-flex">
            <div class="aux-pill">
              <span class="aux-icon">♨️</span>
              <span><strong>Pre-Heater Oven (300°C)</strong> — Sunsun Make (Moisture Removal)</span>
            </div>
            <div class="aux-pill">
              <span class="aux-icon">⚙️</span>
              <span><strong>Scrap Grinding Machine</strong> — TOSHIBA Make</span>
            </div>
            <div class="aux-pill">
              <span class="aux-icon">💨</span>
              <span><strong>Industrial High-Pressure Air Compressor System</strong></span>
            </div>
            <div class="aux-pill">
              <span class="aux-icon">🔧</span>
              <span><strong>7 Pedestal Grinding Machine</strong> — Tool Room Finishing</span>
            </div>
          </div>
        </div>

      </div>
    </section>

    <!-- ===================================================================
         MATERIALS MATRIX INTERACTIVE EXPLORER
         =================================================================== -->
    <section class="geo-section" id="materials">
      <div class="container">
        
        <div class="geo-section-header">
          <div class="geo-kicker">[ POLYMER SCIENCE // PROPERTY MATRIX ]</div>
          <h2 class="geo-section-title">Engineering Grade Plastics Processed</h2>
          <p class="geo-section-subtitle">
            Click on any polymer to inspect mechanical tensile limits, continuous temperature ratings, friction coefficients, and recommended component applications.
          </p>
        </div>

        <div class="materials-explorer-grid">
          
          <div class="materials-tabs-nav" role="tablist" id="materialsTabList">
            <button class="material-nav-btn active" data-mat="delrin" role="tab">
              <span class="mat-code">01</span>
              <span class="mat-name">Delrin (POM / Acetal)</span>
              <span class="mat-badge">Gears &amp; Bushings</span>
            </button>

            <button class="material-nav-btn" data-mat="nylon6gf" role="tab">
              <span class="mat-code">02</span>
              <span class="mat-name">Nylon 6 GF30% (Glass Filled)</span>
              <span class="mat-badge">High Tensile</span>
            </button>

            <button class="material-nav-btn" data-mat="nylon6" role="tab">
              <span class="mat-code">03</span>
              <span class="mat-name">Nylon 6 (Pure Polyamide)</span>
              <span class="mat-badge">Wear &amp; Toughness</span>
            </button>

            <button class="material-nav-btn" data-mat="nylon66" role="tab">
              <span class="mat-code">04</span>
              <span class="mat-name">Nylon 66 (Unfilled)</span>
              <span class="mat-badge">High Heat Polyamide</span>
            </button>

            <button class="material-nav-btn" data-mat="nylon66gf50" role="tab">
              <span class="mat-code">05</span>
              <span class="mat-name">Nylon 66 GF 50%</span>
              <span class="mat-badge">Metal Replacement</span>
            </button>

            <button class="material-nav-btn" data-mat="noryl" role="tab">
              <span class="mat-code">06</span>
              <span class="mat-name">Noryl (Modified PPE)</span>
              <span class="mat-badge">Hydrolytic &amp; Dielectric</span>
            </button>

            <button class="material-nav-btn" data-mat="pc" role="tab">
              <span class="mat-code">07</span>
              <span class="mat-name">Polycarbonate (PC)</span>
              <span class="mat-badge">Impact &amp; Optical</span>
            </button>

            <button class="material-nav-btn" data-mat="abs" role="tab">
              <span class="mat-code">08</span>
              <span class="mat-name">ABS (Terpolymer)</span>
              <span class="mat-badge">Rigid &amp; Gloss</span>
            </button>

            <button class="material-nav-btn" data-mat="polystyrene" role="tab">
              <span class="mat-code">09</span>
              <span class="mat-name">Polystyrene (HIPS / GPPS)</span>
              <span class="mat-badge">Dimensional &amp; Bezels</span>
            </button>

            <button class="material-nav-btn" data-mat="pps" role="tab">
              <span class="mat-code">10</span>
              <span class="mat-name">Polyphenylene Sulfide (PPS)</span>
              <span class="mat-badge">220°C Thermal</span>
            </button>

            <button class="material-nav-btn" data-mat="pu" role="tab">
              <span class="mat-code">11</span>
              <span class="mat-name">Polyurethane (PU / TPU)</span>
              <span class="mat-badge">Elastomer Shock</span>
            </button>

            <button class="material-nav-btn" data-mat="tpe" role="tab">
              <span class="mat-code">12</span>
              <span class="mat-name">Thermoplastic Elastomer (TPE)</span>
              <span class="mat-badge">Flexible Sealing Grip</span>
            </button>

            <button class="material-nav-btn" data-mat="pp" role="tab">
              <span class="mat-code">13</span>
              <span class="mat-name">Polypropylene (PP)</span>
              <span class="mat-badge">Chemical Barrier</span>
            </button>

            <button class="material-nav-btn" data-mat="hdpe" role="tab">
              <span class="mat-code">14</span>
              <span class="mat-name">HDPE &amp; LDPE</span>
              <span class="mat-badge">High Slip</span>
            </button></div>

          <div class="material-detail-card" id="materialDetailViewer">
            <div class="detail-header-row">
              <div>
                <span class="detail-sub-code" id="matDetailCode">POLYMER ID: POM-01 // HOMOPOLYMER / COPOLYMER</span>
                <h3 class="detail-mat-name" id="matDetailName">Delrin (Polyoxymethylene / Acetal)</h3>
              </div>
              <span class="detail-grade-tag" id="matDetailTag">ENGINEERING GRADE</span>
            </div>

            <p class="detail-mat-desc" id="matDetailDesc">
              Delrin is renowned for high mechanical strength, dimensional stability, low coefficient of friction, and superb fatigue endurance. Widely utilized as metal replacements in precision gear systems, cams, and bearings.
            </p>

            <div class="mat-properties-grid">
              <div class="mat-prop-box">
                <span class="prop-title">TENSILE STRENGTH</span>
                <span class="prop-value" id="matPropTensile">70 - 85 MPa</span>
              </div>
              <div class="mat-prop-box">
                <span class="prop-title">MAX SERVICE TEMP</span>
                <span class="prop-value" id="matPropTemp">105°C continuous</span>
              </div>
              <div class="mat-prop-box">
                <span class="prop-title">WEAR &amp; FRICTION</span>
                <span class="prop-value" id="matPropWear">Extremely Low (Self-Lubricating)</span>
              </div>
              <div class="mat-prop-box">
                <span class="prop-title">WATER ABSORPTION</span>
                <span class="prop-value" id="matPropWater">&lt; 0.2% (Dimensional Lock)</span>
              </div>
            </div>

            <div class="mat-applications-box">
              <span class="app-heading">COMMON NEGIZHI APPLICATIONS:</span>
              <div class="app-tags" id="matDetailApps">
                <span class="app-pill">Precision Spur &amp; Helical Gears</span>
                <span class="app-pill">Self-Lubricating Bushings</span>
                <span class="app-pill">Switchgear Actuators</span>
                <span class="app-pill">Conveyor Wear Guides</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>

    <!-- ===================================================================
         TOOL & DIE DESIGN & MANUFACTURING ECOSYSTEM
         =================================================================== -->
    <section class="geo-section dark-alt" id="tooling">
      <div class="container">
        
        <div class="geo-section-header">
          <div class="geo-kicker">[ IN-HOUSE &amp; OUTSOURCING ECOSYSTEM // DIE PRECISION ]</div>
          <h2 class="geo-section-title">Tool &amp; Die Design &amp; Precision Manufacturing</h2>
          <p class="geo-section-subtitle">
            Equipped with CAD/CAM design workstations and advanced outsourcing facilities for sub-micron spark erosion, CNC wire-cutting, and hardened tool steels.
          </p>
        </div>

        <div class="tooling-showcase-grid">
          
          <div class="tooling-visual-panel">
            <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/extracted/mould_tooling.jpg'); ?>" alt="Multi-cavity injection mould die core assembly fabricated by Negizhi Industries" class="tooling-img" loading="lazy" />
            <div class="tooling-caption">
              <span>Multi-Cavity Precision Runner Die Assembly for High-Volume Components</span>
            </div>
          </div>

          <div class="tooling-capabilities-panel">
            <div class="cap-step-item">
              <div class="step-num">01</div>
              <div class="step-content">
                <h4>Tool &amp; Die Design (CAD / CAM)</h4>
                <p>3D component modeling, mould flow simulation, shrinkage optimization, parting line definition, and multi-gate runner balancing.</p>
              </div>
            </div>

            <div class="step-connector"></div>

            <div class="cap-step-item">
              <div class="step-num">02</div>
              <div class="step-content">
                <h4>CNC Machining &amp; Precision Grinding</h4>
                <p>High-precision milling, bolster pocketing, surface grinding, and die-set parallelism alignment within ±0.005 mm.</p>
              </div>
            </div>

            <div class="step-connector"></div>

            <div class="cap-step-item">
              <div class="step-num">03</div>
              <div class="step-content">
                <h4>Wire Cutting &amp; Sparking (EDM)</h4>
                <p>Sub-micron wire electrical discharge machining for tight gear profiles, sharp internal corners, and intricate electrode cavities.</p>
              </div>
            </div>

            <div class="step-connector"></div>

            <div class="cap-step-item">
              <div class="step-num">04</div>
              <div class="step-content">
                <h4>Hardening &amp; Optical Mirror Polishing</h4>
                <p>Vacuum heat treatment (HRC 50–54), corrosion-resistant chrome plating, and SPI A1 optical finish polishing for flawless part release.</p>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>

    <!-- ===================================================================
         INSPECTION & TESTING FACILITY (QUALITY LAB)
         =================================================================== -->
    <section class="geo-section" id="quality">
      <div class="container">
        
        <div class="geo-section-header">
          <div class="geo-kicker">[ QUALITY ASSURANCE // METROLOGY LAB ]</div>
          <h2 class="geo-section-title">Inspection &amp; Mechanical Testing Facilities</h2>
          <p class="geo-section-subtitle">
            Calibrated metrology instruments guarantee dimensional compliance, durometer hardness, and batch repeatability.
          </p>
        </div>

        <div class="quality-instruments-grid">
          
          <div class="instrument-card">
            <div class="inst-icon">📏</div>
            <div class="inst-make">Mitutoyo Calibration</div>
            <h3 class="inst-name">Vernier Calipers (0 - 200 mm)</h3>
            <p class="inst-desc">High precision digital calipers for wall thickness, pitch diameters, and step heights.</p>
          </div>

          <div class="instrument-card">
            <div class="inst-icon">⭕</div>
            <div class="inst-make">Inspection Grade</div>
            <h3 class="inst-name">Bore Gauges - GO / NOGO (10 - 60 mm)</h3>
            <p class="inst-desc">Fast cylindrical hole verification ensuring gear shafts slide with exact press-fit tolerances.</p>
          </div>

          <div class="instrument-card">
            <div class="inst-icon">⚖️</div>
            <div class="inst-make">Prestige Make</div>
            <h3 class="inst-name">Precision Weighing Balance (30 Kg)</h3>
            <p class="inst-desc">Gram-level shot consistency checking to catch sink marks or internal porosity early in the production run.</p>
          </div>

          <div class="instrument-card">
            <div class="inst-icon">💎</div>
            <div class="inst-make">Durometer Test</div>
            <h3 class="inst-name">Shore Hardness Gauge</h3>
            <p class="inst-desc">Shore D and Shore A testing to verify exact crosslinking and structural rigidity of engineered plastics.</p>
          </div>

          <div class="instrument-card">
            <div class="inst-icon">🔬</div>
            <div class="inst-make">Sub-Mil Testing</div>
            <h3 class="inst-name">Micrometer Calipers</h3>
            <p class="inst-desc">Measuring step shoulders, tooth root widths, and runner gate cutoff tolerances down to ±0.001 mm.</p>
          </div>

          <div class="instrument-card">
            <div class="inst-icon">🎯</div>
            <div class="inst-make">Dial Gauge</div>
            <h3 class="inst-name">Bore Dial Indicators</h3>
            <p class="inst-desc">Precision internal diameter roundness and runout profiling for critical rotating bushings.</p>
          </div>

        </div>

      </div>
    </section>

    <!-- ===================================================================
         INTERACTIVE RFQ & QUOTE ESTIMATOR
         =================================================================== -->
    <section class="geo-section dark-alt" id="rfq">
      <div class="container">
        
        <div class="geo-section-header">
          <div class="geo-kicker">[ RAPID ESTIMATION // VALUE ENGINEERING ]</div>
          <h2 class="geo-section-title">Request for Quotation (RFQ) &amp; Technical Estimator</h2>
          <p class="geo-section-subtitle">
            Configure your technical component specifications to initiate a rapid engineering review with our technical engineering desk.
          </p>
        </div>

        <div class="rfq-calculator-container">
          
          <form class="rfq-form" id="rfqForm" onsubmit="event.preventDefault(); submitRFQ();">
            
            <div class="form-row">
              <div class="form-group">
                <label for="rfqPartName">Component Name / Drawing Number</label>
                <input type="text" id="rfqPartName" placeholder="e.g. 42-Tooth Helical Gear or Terminal Housing" required />
              </div>
              <div class="form-group">
                <label for="rfqMaterial">Target Engineering Polymer</label>
                <select id="rfqMaterial" required>
                  <option value="Delrin (POM)">Delrin (POM / Acetal)</option>
                  <option value="Nylon 6 GF30%">Nylon 6 GF30% (Glass Filled)</option>
                  <option value="Nylon 6">Nylon 6 (Unfilled)</option>
                  <option value="Nylon 66 unfilled">Nylon 66 (Unfilled)</option>
                  <option value="Nylon 66 GF 50%">Nylon 66 GF 50% (High Modulus Structural)</option>
                  <option value="Noryl">Noryl (Modified Polyphenylene Ether / PPE)</option>
                  <option value="Polycarbonate (PC)">Polycarbonate (PC)</option>
                  <option value="ABS">ABS (General Purpose / Flame Retardant)</option>
                  <option value="Polystyrene">Polystyrene (HIPS / GPPS)</option>
                  <option value="PPS">Polyphenylene Sulfide (PPS)</option>
                  <option value="Polyurethane (PU)">Polyurethane (PU)</option>
                  <option value="Thermoplastic Elastomer">Thermoplastic Elastomer (TPE)</option>
                  <option value="PP">Polypropylene (PP)</option>
                  <option value="HDPE / LDPE">HDPE / LDPE</option>
                  <option value="Consulting Needed">Help Me Select the Best Material</option>
                </select>
              </div>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label for="rfqQuantity">Monthly / Batch Quantity</label>
                <select id="rfqQuantity">
                  <option value="500 - 2,000 pcs">Pilot Batch (500 - 2,000 pcs)</option>
                  <option value="2,000 - 10,000 pcs" selected>Medium Run (2,000 - 10,000 pcs)</option>
                  <option value="10,000 - 50,000 pcs">High Volume (10,000 - 50,000 pcs)</option>
                  <option value="50,000+ pcs">Mass Production (50,000+ pcs)</option>
                </select>
              </div>

              <div class="form-group">
                <label for="rfqToolingStatus">Mould Tooling Status</label>
                <select id="rfqToolingStatus">
                  <option value="Need Tool Designed & Manufactured">Need Negizhi to Design &amp; Make Mould Die</option>
                  <option value="Existing Mould Die Available">We have Existing Mould Die Ready to Run</option>
                  <option value="Need Die Modification / Repair">Existing Die Needs Modification/Repair</option>
                </select>
              </div>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label for="rfqContactName">Your Full Name</label>
                <input type="text" id="rfqContactName" placeholder="e.g. Rajesh Kumar" required />
              </div>
              <div class="form-group">
                <label for="rfqCompany">Company / Industry Name</label>
                <input type="text" id="rfqCompany" placeholder="e.g. Precision Gears Pvt Ltd" required />
              </div>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label for="rfqEmail">Business Email Address</label>
                <input type="email" id="rfqEmail" placeholder="e.g. rajesh@precisiongears.com" required />
              </div>
              <div class="form-group">
                <label for="rfqPhone">Phone / WhatsApp Number</label>
                <input type="tel" id="rfqPhone" placeholder="+91 98765 43210" required />
              </div>
            </div>

            <div class="form-group">
              <label for="rfqNotes">Technical Specifications / Part Weight / Drawing Notes</label>
              <textarea id="rfqNotes" rows="3" placeholder="Mention tolerances, operating environment (temp, chemicals), or insert moulding details..."></textarea>
            </div>

            <div class="rfq-actions-row">
              <button type="submit" class="btn-geo-primary btn-large" id="rfqSubmitBtn">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                <span id="rfqSubmitText">Submit Technical RFQ</span>
              </button>

              <a href="https://wa.me/918610888097?text=Hi%20Negizhi%20Industries,%20I%20would%20like%20to%20get%20a%20quote%20for%20engineering%20plastic%20components." target="_blank" rel="noopener noreferrer" class="btn-geo-whatsapp">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
                <span>Direct WhatsApp Chat</span>
              </a>
            </div>

            <div id="rfqSuccessMsg" class="rfq-success-message"></div>
            <div id="rfqErrorMsg" class="rfq-error-message"></div>

          </form>

        </div>

      </div>
    </section>

    <!-- ===================================================================
         OFFICIAL CONTACT & FACTORY LOCATION SECTION
         =================================================================== -->
    <section class="geo-section" id="contact">
      <div class="container">
        
        <div class="geo-section-header">
          <div class="geo-kicker">[ FACTORY LOCATION // ARASUR COIMBATORE ]</div>
          <h2 class="geo-section-title">Direct Corporate &amp; Manufacturing Contacts</h2>
          <p class="geo-section-subtitle">
            Visit our manufacturing plant or connect directly with our proprietor.
          </p>
        </div>

        <div class="contact-details-card">
          <div class="contact-card-header">
            <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/logo.png'); ?>" alt="Negizhi Industries Logo" class="contact-logo" />
            <div>
              <h3 class="contact-company-title">NEGIZHI INDUSTRIES</h3>
              <p class="contact-proprietor">Proprietor: <strong>MATHIBHARATHI DHANARAJ</strong></p>
            </div>
          </div>

          <div class="contact-data-grid">
            <div class="contact-item">
              <div class="contact-item-icon">📍</div>
              <div class="contact-item-body">
                <span class="contact-label">FACTORY &amp; OFFICE ADDRESS:</span>
                <span class="contact-val">5/160A, 79/2, Arasur Post, Arasur (PO), Sulur (TK), Coimbatore - 641 407, Tamil Nadu, India.</span>
              </div>
            </div>

            <div class="contact-item">
              <div class="contact-item-icon">📞</div>
              <div class="contact-item-body">
                <span class="contact-label">DIRECT PHONE / WHATSAPP:</span>
                <a href="tel:+918610888097" class="contact-link">+91 86108 88097</a>
              </div>
            </div>

            <div class="contact-item">
              <div class="contact-item-icon">✉️</div>
              <div class="contact-item-body">
                <span class="contact-label">OFFICIAL EMAIL ID:</span>
                <a href="mailto:plasticnegizhiindustries@gmail.com" class="contact-link">plasticnegizhiindustries@gmail.com</a>
              </div>
            </div>

            <div class="contact-item">
              <div class="contact-item-icon">📜</div>
              <div class="contact-item-body">
                <span class="contact-label">GSTIN REGISTRATION:</span>
                <span class="contact-val mono-badge">33HFHPD0907Q1ZA</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  </main>

  <!-- ===================================================================
       FOOTER
       =================================================================== -->
  <footer class="geo-footer">
    <div class="container geo-footer-inner">
      <div class="footer-col-brand">
        <a href="#hero" class="footer-brand-link" aria-label="Negizhi Industries">
          <img src="<?php echo esc_url(NEGIZHI_PLUGIN_URL . 'assets/logo-horizontal-clean.png'); ?>" alt="Negizhi Industries - Crafting Quality : Shaping Tomorrow" class="footer-logo" width="220" height="43" loading="lazy" />
        </a>
        <p class="footer-tagline">CRAFTING QUALITY : SHAPING TOMORROW</p>
        <p class="footer-sub">Specialist for engineering plastic components in mechanical and electrical applications. Up to 200-Ton capacity in Coimbatore, Tamil Nadu, India.</p>
      </div>

      <div class="footer-col-nav">
        <h4>Navigation</h4>
        <ul>
          <li><a href="#hero">Home</a></li>
          <li><a href="#about">About Negizhi</a></li>
          <li><a href="#moulding-cycle">Moulding Cycle</a></li>
          <li><a href="#products">Component Catalog</a></li>
          <li><a href="#machinery">Machinery Fleet</a></li>
          <li><a href="#materials">Polymer Matrix</a></li>
          <li><a href="#tooling">Tool &amp; Die Room</a></li>
          <li><a href="#quality">Metrology Lab</a></li>
          <li><a href="#clients">Customer Portfolio</a></li>
          <li><a href="#rfq">Request a Quote</a></li>
        </ul>
      </div>

      <div class="footer-col-materials">
        <h4>Processed Polymers</h4>
        <div class="footer-tags-cloud">
          <span>Delrin (POM)</span>
          <span>Nylon 6 GF30%</span>
          <span>Nylon 6</span>
          <span>Polycarbonate (PC)</span>
          <span>ABS</span>
          <span>PPS</span>
          <span>Polyurethane (PU)</span>
          <span>PP</span>
          <span>HDPE</span>
          <span>LDPE</span>
        </div>
      </div>
    </div>

    <div class="footer-bottom-bar">
      <div class="container footer-bottom-inner">
        <span>© 2025–2026 NEGIZHI INDUSTRIES. All Rights Reserved. Coimbatore - 641 407, India.</span>
        <span>Engineered with Geometric Industrial Precision.</span>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  
</div>

<?php wp_footer(); ?>
</body>
</html>
